package com.example.crud_app;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView listView = null;
    Button bCreate = null;
    final Context context = this;
    ProductAdapter productAdapter;
    public static String name;
    public static float price;
    public static int img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        bCreate = findViewById(R.id.bCreate);
       productAdapter = new ProductAdapter();

        String[] listItem = new String[productAdapter.products.size()];
        for (int i = 0; i < productAdapter.products.size(); i++) {
            listItem[i] = productAdapter.products.get(i).getImage()+
                    productAdapter.products.get(i).getName() + productAdapter.products.get(i).getPrice();
        }
        listView.setAdapter(productAdapter);
        img = -1;
        setArray();

        // Add new Product click listener
        bCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, createForm.class);
                startActivity(intent);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            }
        });
        productAdapter.notifyDataSetChanged();
    }

    public void setArray() {
        Thread t = new Thread() {
            @Override
            public void run() {
                while (!isInterrupted()) {
                    try {
                        Thread.sleep(10);  //1000ms = 1 sec
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (img != -1) {
                                    Product product = new Product(img, name, price);
                                    productAdapter.products.add(product);
                                    img = -1;
                                    String[] listItem = new String[productAdapter.products.size()];
                                    for (int i = 0; i < productAdapter.products.size(); i++) {
                                        listItem[i] = productAdapter.products.get(i).getImage()
                                                + productAdapter.products.get(i).getName()
                                                + "\n" + productAdapter.products.get(i).getPrice();
                                    }

                                    listView.setAdapter(productAdapter);
                                    productAdapter.notifyDataSetChanged();
                                }
                            }
                        });
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        t.start();
        productAdapter.notifyDataSetChanged();
    }
}
