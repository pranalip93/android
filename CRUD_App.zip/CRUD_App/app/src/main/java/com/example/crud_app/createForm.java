package com.example.crud_app;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class createForm extends AppCompatActivity {
    Button bDone = null;
    ImageView imageView=null;
    private static final int PICK_IMAGE = 100;
    Uri imageUri;
    EditText productName=null;
    EditText productPrice=null;
    String resourceName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_form);
        bDone=findViewById(R.id.bDone);
        imageView=findViewById(R.id.imageView2);
        productName=findViewById(R.id.editTextProductName);
        productPrice=findViewById(R.id.editTextProductPrice);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });
        resourceName=imageView.getResources().toString();
        final Drawable drawable = imageView.getDrawable();

        bDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.img=imageView.getResources().getIdentifier(String.valueOf(drawable),"drawable",getPackageName());
                MainActivity.name=productName.getText().toString();
                MainActivity.price = ParseFloat(productPrice.getText(). toString());
                finish();
            }
        });
    }
    Integer ParseInteger(String image_view)
    {
        if (image_view != null && productPrice.length() > 0) {
            try {
                return Integer.parseInt(image_view);
            } catch (Exception e) {
                return -1;   // or some value to mark this field is wrong. or make a function validates field first ...
            }
        } else return 0;

    }
    float ParseFloat(String productPrice) {
        if (productPrice != null && productPrice.length() > 0) {
            try {
                return Float.parseFloat(productPrice);
            } catch (Exception e) {
                return -1;   // or some value to mark this field is wrong. or make a function validates field first ...
            }
        } else return 0;
    }

    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        gallery.setType("image/*");
        startActivityForResult(gallery, PICK_IMAGE);

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        try {
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE ){
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
