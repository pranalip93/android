package com.example.crud_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class readListData extends AppCompatActivity {
    public static  String name;
    public static float price;
    public static int img;
    ProductAdapter productAdapter;
    ImageView productImage=null;
    TextView productName=null;
    TextView productPrice=null;
    public static int position;
    String image;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.read_form);
        productName=findViewById(R.id.nameView);
        productPrice=findViewById(R.id.readprice);
        productImage=findViewById(R.id.readimageView);
       /* productAdapter= new ProductAdapter();
        Product product = new Product(img, name, price);
        productAdapter.products.add(product);*/
        productName.setText(productAdapter.products.get(position).getName());
        productPrice.setText("$" + String.format("%.2f", productAdapter.products.get(position).getPrice()));
        productImage.setImageResource(productAdapter.products.get(position).getImage());
        }

    }

