package com.example.crud_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class UpdateForm extends AppCompatActivity {
    static ProductAdapter productAdapter;
    ImageView productImage=null;
    EditText productName=null;
    EditText productPrice=null;
    private static final int PICK_IMAGE = 100;
    public static int pos;
    Uri imageUri;
    Button bUpdate=null;
    static ArrayList<Product> product_list;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_form);

        productAdapter.products=product_list;
        productName=findViewById(R.id.updateName);
        productPrice=findViewById(R.id.updatePrice);
        productImage=findViewById(R.id.updateImageView);
        productName.setText(productAdapter.products.get(pos).getName());
        productPrice.setText(String.format("%.2f", productAdapter.products.get(pos).getPrice()));
        productImage.setImageResource(productAdapter.products.get(pos).getImage());
        bUpdate=findViewById(R.id.buttonUpdateDone);

        productImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        bUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //product_list.get(pos).setImage(ParseInteger(productImage.getDrawable().toString()));
                product_list.get(pos).setName(productName.getText().toString());
                product_list.get(pos).setPrice(ParseFloat(productPrice.getText().toString()));
                ProductAdapter.products=product_list;
                productAdapter.notifyDataSetChanged();
                finish();
            }
        });
    }

    Integer ParseInteger(String productimg) {
        if (productimg != null && productimg.length() > 0) {
            try {
                return Integer.parseInt(productimg);
            } catch (Exception e) {
                return -1;   // or some value to mark this field is wrong. or make a function validates field first ...
            }
        } else return 0;
    }

    float ParseFloat(String productPrice) {
        if (productPrice != null && productPrice.length() > 0) {
            try {
                return Float.parseFloat(productPrice);
            } catch (Exception e) {
                return -1;   // or some value to mark this field is wrong. or make a function validates field first ...
            }
        } else return 0;
    }
    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE) {
            imageUri = data.getData();
            productImage.setImageURI(imageUri);
        }
    }
}
