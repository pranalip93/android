package com.example.crud_app;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class ProductAdapter extends BaseAdapter {
    static ArrayList<Product> products = new ArrayList<>();
    TextView productTextView=null;
    TextView  priceTextView=null;
    Button bEdit=null;
    Button bDelete=null;
    private Context context;

    public ProductAdapter() {
        if(products.isEmpty()) {
            products.add(new Product(R.drawable.iphone,"iphone 12", 1299.99f));
            products.add(new Product(R.drawable.nike, "Nike Shoes", 100.77f));
            products.add(new Product(R.drawable.nikon, "Nikon", 129.85f));
            products.add(new Product(R.drawable.macbook, "MacBook Pro", 2205.99f));
        }

    }

    public ProductAdapter(Context context) {
        this.context = context;
    }
    @Override
    public int getCount() {
        return products.size();
    }

    @Override
    public Object getItem(int position) {
        return this;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(final int position, View v, final ViewGroup parent) {
        notifyDataSetChanged();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        context=parent.getContext();
        final RelativeLayout relativeLayout = (RelativeLayout) layoutInflater.inflate(R.layout.list_item, null);
        v=relativeLayout.findViewById(R.id.list);
        final ImageView imageView = relativeLayout.findViewById(R.id.imageView);
        imageView.setImageResource(products.get(position).getImage());
        productTextView = relativeLayout.findViewById(R.id.productTextView);
        productTextView.setText(products.get(position).getName());
        priceTextView = relativeLayout.findViewById(R.id.priceTextView);
        priceTextView.setText("$" + String.format("%.2f", products.get(position).getPrice()));
        bEdit= relativeLayout.findViewById(R.id.bEdit);
        bDelete=relativeLayout.findViewById(R.id.bDelete);

        bDelete.setTag(position);
        bEdit.setTag(position);
        productTextView.setTag(position);

             //Delete click listener
             bDelete.setOnClickListener(new  View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int a = (int) v.getTag();
                    System.out.println(products);
                    products.remove(products.get(a));
                    notifyDataSetChanged();
                }
            });

             //Update click listener
             bEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    notifyDataSetChanged();
                    int a=(int) v.getTag();
                    UpdateForm.pos=a;
                    UpdateForm.productAdapter=ProductAdapter.this;
                    Intent intent = new Intent(context, UpdateForm.class);
                    UpdateForm.product_list=products;
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(intent);
                }
            });

            //Read operation click listener
            productTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, readListData.class);
                    int a= (int) v.getTag();
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    readListData.img=products.get(a).getImage();
                    readListData.name=productTextView.getText().toString();
                    readListData.price=ParseFloat(priceTextView.getText().toString());
                    readListData.position=a;
                    context.getApplicationContext().startActivity(intent);
                }
            });
            notifyDataSetChanged();
            return relativeLayout;

    }

    float ParseFloat(String productPrice) {
        if (productPrice != null && productPrice.length() > 0) {
            try {
                return Float.parseFloat(productPrice);
            } catch (Exception e) {
                return -1;   // or some value to mark this field is wrong. or make a function validates field first ...
            }
        } else return 0;
    }
}

